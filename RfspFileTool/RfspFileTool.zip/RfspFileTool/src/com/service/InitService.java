package com.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Timer;

import org.apache.log4j.Logger;

import com.domain.Index;
import com.domain.MyCalendar;
import com.domain.MyTimeTask;
import com.domain.TimeDuration;

public class InitService {
	Logger logger = Logger.getLogger(InitService.class);
	String srcPath = null;
	String tradeDate = null;
	String manualTime = null;
	List<Index> indexList = null;
	MainService ms = null;
	private Map<String,Timer> timerMap;
	private Map<String,List<Index>> exeMap = new HashMap<String, List<Index>>();
	/**
	 * ��ʼ������ȡ�����ļ���Ϣ
	 * @return
	 * by yzx
	 */
	public String init(){
		try {
			MyCalendar myCalendar = new MyCalendar(new Date());
			myCalendar.addDay(-3);
			tradeDate = myCalendar.getDateString();
			manualTime = myCalendar.getTimeHHmmss();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return "���ڸ�ʽת������";
		}
		try {
			srcPath = readSystemConfig();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return "system�����ļ������ڻ������ݣ�";
		} catch (IOException e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return "��ȡsystem�����ļ�IO�쳣";
		}
		System.out.println(srcPath);
		if(!new File(srcPath).exists()){
			return "����Դ·�������ڣ�";
		}
		try {
			indexList = readCodeListConfig();
		} catch (NumberFormatException e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return "code_list�����ļ����ݸ�ʽת������";
		} catch (IOException e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return "code_list�����ļ�IO�쳣��";
		}
		if(indexList == null || indexList.size() < 0){
			return "code_list�����ļ������ڻ������ݣ�";
		}
		timerMap = new HashMap<String, Timer>();
		ms = new MainService(srcPath, tradeDate, manualTime);
		for (Index index : indexList) {
			if("0".equals(index.getExeTime())){
				continue;
			}
			if(exeMap.containsKey(index.getExeTime())){
				exeMap.get(index.getExeTime()).add(index);
			}else{
				List<Index> list = new LinkedList<Index>();
				list.add(index);
				exeMap.put(index.getExeTime(), list);
			}
		}
		return null;
	}
	public void loadData(){
		ms.loadData(indexList);
	}
	/**
	 * ��ʼ����ʱ��
	 */
	public void initTimer() {
		
		for (Entry<String, List<Index>> entry : exeMap.entrySet()) {
			
			MyTimeTask mtt = new MyTimeTask(entry.getKey(),entry.getValue(), ms);
			Timer newTimer = new Timer(entry.getKey());
			MyCalendar mc = new MyCalendar(new Date());
			try {
				mc.setHHmm(entry.getKey());
//				System.out.println(mc.getDate().toLocaleString());
//				long period = 5 * 60 * 1000;
				long period = 24 * 60 * 60 * 1000;
				newTimer.scheduleAtFixedRate(mtt, mc.getDate(), period);
				timerMap.put(entry.getKey(), newTimer);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	/**
	 * ��ȡcode_list�����ļ���Ϣ
	 * @return
	 * by yzx
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	private List<Index> readCodeListConfig() throws NumberFormatException, IOException{
		File file = new File("config/code_list.txt");
		if(!file.exists()){
			return null;
		}
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		List<Index> list = new LinkedList<Index>();
		fis = new FileInputStream(file);
		isr = new InputStreamReader(fis);
		br = new BufferedReader(isr);
		String line = null;
		Index index = null;
		while((line = br.readLine()) != null){
			if(line.charAt(0) != '#'){
				String[] splits = line.split(",");
				index = new Index();
				index.setIndexCode(splits[0].toUpperCase());
				index.setExeTime(splits[splits.length-1]);
				index.setSpaceTime(Integer.parseInt(splits[splits.length-2]));
				index.setCloseTime(splits[splits.length-3]);
				List<TimeDuration> times = new ArrayList<TimeDuration>();
				String[] timeStrs = null;
				for (int i = 1; i < splits.length-3; i++) {
					timeStrs = splits[i].split("-");
					if(timeStrs.length == 2){
						times.add(new TimeDuration(timeStrs[0], timeStrs[1], index.getSpaceTime()));
						if(i == splits.length-4){
							index.setEndTime(timeStrs[1]);
						}
					}
				}
				index.setTimes(times);
				list.add(index);
			}
		}
		if(br!=null){
			br.close();
		}
		if(isr != null){
			isr.close();
		}
		if(fis != null){
			fis.close();
		}
		return list;
		
	}
	/**
	 * ��ȡSystem�����ļ�
	 * @return
	 * by yzx
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	private String readSystemConfig() throws FileNotFoundException, IOException {
		Properties p = new Properties();
		File file = new File("config/System.properties");
		String srcPath = null;
		p.load(new FileInputStream(file));
		srcPath = p.getProperty("sourcepath");
		return srcPath;
	}
}
