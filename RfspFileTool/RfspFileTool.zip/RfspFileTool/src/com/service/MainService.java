package com.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.domain.Index;
import com.domain.MD5Util;
import com.domain.MyCalendar;
import com.domain.ResultFile;
import com.domain.TimeDuration;
import com.main.MainDialog;

public class MainService {
	Logger logger = Logger.getLogger(MainService.class);
	String srcPath = null;
	String tradeDate = null;
	String manualTime = null;
	
	public MainService(String srcPath,String tradeDate,String manualTime){
		this.srcPath = srcPath;
		this.tradeDate = tradeDate;
		this.manualTime = manualTime;
	}
	
	/**
	 * ��������
	 * @return
	 */
	public boolean loadData(List<Index> indexList) {
		for (Index index : indexList) {
			String result = loadData(index);
			MainDialog.getInstance().showMessage(index.getIndexCode(), result);
		}
		return true;
	}
	/**
	 * ��������
	 * @return
	 */
	public String loadData(Index index) {
		String directoryPath = srcPath + "/" + tradeDate;
		if(!new File(directoryPath).exists()){
			return tradeDate + "���ݲ�����";
		}
		try {
			MyCalendar mc = new MyCalendar(new Date());
			if(mc.getTimeHHmm().compareTo(index.getEndTime()) < 0){
				return tradeDate + "��������ȱʧ���޷������ļ�";
			}
			if(decodeData(index,directoryPath)){
				return tradeDate +  "�ļ����ɳɹ���";
			}else{
				return tradeDate +  "ȱʧ�������ݣ��޷������ļ���";
			}
			
		} catch (IOException e) {
//			e.printStackTrace();
//			logger.error(e.getMessage(), e);
			return "�ļ�����ʧ�ܣ��ļ���ռ��";
		} catch (ParseException e1) {
//			e1.printStackTrace();
//			logger.error(e1.getMessage(), e1);
			return "�ļ�����ʧ�ܣ��ַ�������ת���쳣";
		}
	}
	/**
	 * ���Index��ȡ��Ӧ���ݲ�����
	 * @param index
	 * @param directoryPath
	 * by yzx
	 * @throws IOException 
	 * @throws ParseException 
	 */
	private boolean decodeData(Index index, String directoryPath) throws IOException, ParseException {
		List<TimeDuration> times = index.getTimes();
		ResultFile rf = new ResultFile();
		rf.setIndexCode(index.getIndexCode());
		rf.setDatas(new LinkedHashMap<String, String[]>());
		rf.setTradeDate(tradeDate);
		rf.setType(index.calType());
		rf.setSpace(index.getSpaceTime());
		rf.setCount(index.getCount());
		File rootFile = new File(directoryPath);
		File[] listFiles = rootFile.listFiles();
			for (TimeDuration timeDuration : times) {
					findData(timeDuration.getBegin(),timeDuration.getEnd(),timeDuration.getCount(),index,directoryPath,rf,listFiles);
			}
			if(index.calType() != 0){
				findCloseData(index.getCloseTime(),index,directoryPath,rf,listFiles);
			}
		return writeFile(rf);
	}
	/**
	 * ���ɽ���ļ�
	 * @param rf
	 * @throws IOException 
	 */
	private boolean writeFile(ResultFile rf) throws IOException {
			if(rf.getDatas().size() < rf.getCount()){
				return false;
			}
			File dir = new File("files/rfsp/"+ tradeDate);
			if(!dir.exists()){
				dir.mkdirs();
			}
			File file = new File(dir +"/csiRFSP"+rf.getIndexCode()+tradeDate+".txt");
			FileOutputStream fos = null;
			OutputStreamWriter osw = null;
			BufferedWriter bw = null;
//				if(!file.exists()){
//					file.createNewFile();
//				}
				fos = new FileOutputStream(file);
				osw = new OutputStreamWriter(fos);
				bw = new BufferedWriter(osw);
				String line = null;
				line = "01|"+rf.getTradeDate()+"|"+"        "+rf.getCount();
				bw.write(line);
				bw.write("\n");
//		bw.newLine();
//			logger.info(line);
				for (Entry<String, String[]> entry : rf.getDatas().entrySet()) {
					line = entry.getValue()[0]+"|"+rf.getIndexCode()+"|  "+entry.getValue()[1];
					bw.write(line);
					bw.write("\n");
//			bw.newLine();
//				logger.info(line);
				}
				rf.calResult();
				line = rf.getResultName() + "|" + rf.getIndexCode() + "|" + rf.getResultValue();
				bw.write(line);
				bw.write("\n");
//		bw.newLine();
//			logger.info(line);
				bw.flush();
				bw.close();
				osw.close();
				fos.close();
				bw=null;
				osw=null;
				fos=null;
				
				
				File file2 = new File(dir + "/csiRFSP"+rf.getIndexCode()+tradeDate+".flg");
				if(!file2.exists()){
					file2.createNewFile();
				}
				fos = new FileOutputStream(file2);
				osw = new OutputStreamWriter(fos);
				bw = new BufferedWriter(osw);
				String md5 = MD5Util.getMD5(file);
				line = null;
				StringBuilder sb = new StringBuilder();
				appendStr(sb, 60, file.getName());
				appendStr(sb, 16, file.length()+"");
				appendStr(sb, 8, tradeDate);
				appendStr(sb, 8, manualTime);
				appendStr(sb, 12, (rf.getCount() + 2)+"");
				if(md5 == null){
					md5 = "";
				}
				appendStr(sb, 64, md5);
				appendStr(sb, 64, "");
				sb.deleteCharAt(sb.length() - 1);
				line = sb.toString();
				bw.write(line);
				bw.write("\n");
//			bw.newLine();
//			logger.info(line);
				bw.flush();
				bw.close();
				osw.close();
				fos.close();
				bw=null;
				osw=null;
				fos=null;
				file = null;
				file2 = null;
			return true;
	}
	/**
	 * append string with num counts of space
	 * @param sb
	 * @param num
	 */
	private void appendStr(StringBuilder sb, int num,String content) {
		sb.append(content);
		for (int i = 0; i < num-content.length(); i++) {
			sb.append(" ");
		}
		sb.append("|");
	}
	
	/**
	 * ������������
	 * @param closeTime
	 * @param index
	 * @param directoryPath
	 * @param rf
	 * @param listFiles
	 * @throws ParseException
	 * @throws IOException 
	 */
	private void findCloseData(String closeTime, Index index, String directoryPath, ResultFile rf, File[] listFiles) throws ParseException, IOException {
		MyCalendar time = new MyCalendar();
		time.setHHmm(closeTime);
		String path = null;
		path = "csi" + tradeDate + time.getTimeHHmmss() + ".txt"; 
		searchData(directoryPath, listFiles, path, rf, 1, time.getTimeHHmmss());
	}
	/**
	 * ����ʱ��ε�����
	 * @param startTime
	 * @param endTime
	 * @param count
	 * @param index
	 * @param directoryPath
	 * @param rf 
	 * @param listFiles 
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws Exception
	 * by yzx
	 */
	private void findData(String startTime, String endTime, int count, Index index, String directoryPath, ResultFile rf, File[] listFiles) throws ParseException, IOException{
		MyCalendar time = new MyCalendar();
		time.setHHmm(startTime);
		String path = null;
		for (int i = 0; i < count-1; i++) {
			path = "csi" + tradeDate + time.getTimeHHmmss() + ".txt"; 
			searchData(directoryPath, listFiles, path, rf, 0, time.getTimeHHmmss());
			time.addMinute(rf.getSpace());
		}
		if(!(rf.getType() == 2 && index.getEndTime().equals(endTime))){
			time.setHHmm(endTime);
			path = "csi" + tradeDate + time.getTimeHHmmss() + ".txt"; 
			searchData(directoryPath, listFiles, path, rf, 0, time.getTimeHHmmss());
		}
		
	}
	/**
	 * ��Ѱ�����ļ���Ϣ
	 * @param directoryPath
	 * @param listFiles
	 * @param path
	 * @param rf
	 * @param type : 0 : ʵʱ�����ݣ� 1 �����̼�����
	 * by yzx
	 * @param srcName 
	 * @throws IOException 
	 */
	private void searchData(String directoryPath, File[] listFiles, String path, ResultFile rf, int type, String srcName) throws IOException {
		for (File file : listFiles) {
			String name = file.getName();
			if(path.compareTo(name) <= 0){
				if(getData(rf,name,directoryPath,type,srcName)){
//					System.out.println(name);
					break;
				}
			}
		}
	}
	/**
	 * �������ļ���ȡ��Ϣ
	 * @param rf
	 * @param name
	 * @param directoryPath
	 * @param type : 0 : ʵʱ�����ݣ� 1 �����̼�����
	 * @param srcName 
	 * @return
	 * by yzx
	 * @throws IOException 
	 */
	private boolean getData(ResultFile rf, String name, String directoryPath, int type, String srcName) throws IOException {
		synchronized (this) {
			File file = new File(directoryPath + "/" + name);
			FileInputStream fis = null;
			InputStreamReader isr = null;
			BufferedReader br = null;
			boolean flag = false;
			fis = new FileInputStream(file);
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			String line = null;
			String time = null;
			line = br.readLine();
			if(line != null ){
				time = line.split("\\|")[3];
			}
			while((line = br.readLine()) != null){
//			logger.info(line);
				String[] strings = line.split("\\|");
				if("01".equals(strings[0])){
					if(rf.getIndexCode().equals(strings[2])){
						if(type == 0){
							if(!"0.0000".equals(strings[5].trim())){
								rf.getDatas().put(srcName,new String[]{time.trim(), strings[5].trim()});
								flag = true;
							}
							break;
						}else if(type == 1){
							if(!"0.0000".equals(strings[9].trim())){
								rf.getDatas().put("close",new String[]{"Close ", strings[9].trim()});
								flag = true;
							}
							break;
						}
					}
				}
			}
			if(br!=null){
				br.close();
			}
			if(isr != null){
				isr.close();
			}
			if(fis != null){
				fis.close();
			}
			return flag;
		}
	}
	
}
