package com.domain;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;

public class TimeSchedule{
	private static TimeSchedule instance = new TimeSchedule();
	private Map<String,Timer> timerMap;
	private TimeSchedule() {
		timerMap = new HashMap<String, Timer>();
	}

	public static TimeSchedule getInstance(){
		return instance;
	}
	
	public void add(String name, Timer timer){
		timerMap.put(name, timer);
	}
}
