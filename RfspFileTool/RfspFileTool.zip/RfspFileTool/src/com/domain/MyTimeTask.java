package com.domain;

import java.util.List;
import java.util.TimerTask;

import com.service.MainService;

public class MyTimeTask extends TimerTask {
	private String time;
	private List<Index> list;
	private MainService service;
	public MyTimeTask(String time,List<Index> list, MainService mainService) {
		this.time = time;
		this.list = list;
		this.service = mainService;
	}
	@Override
	public void run() {
		service.loadData(list);
	}

}
