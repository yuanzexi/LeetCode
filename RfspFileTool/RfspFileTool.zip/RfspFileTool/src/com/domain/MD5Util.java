package com.domain;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
	private static final String[] HEX_MAP = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
	public static String getMD5(File file){
		String value = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			MappedByteBuffer byteBuffer = fis.getChannel().map(FileChannel.MapMode.READ_ONLY, 0, file.length());
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update(byteBuffer);
			value = byteToHex(md5.digest());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}finally {
			if (null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return value;
	}

	private static String byteToHex(byte[] digest) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < digest.length; i++) {
			sb.append(HEX_MAP[((digest[i]>>4) & 0x0F)]);
			sb.append(HEX_MAP[(digest[i] & 0x0F)]);
		}
		return sb.toString();
	}
	public static void main(String[] args) {
		File file = new File("files/rsfp/csiRFSPCES12020160513.txt");
		String md5 = getMD5(file);
		System.out.println(md5);
	}
}
