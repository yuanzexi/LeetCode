package com.domain;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

public class ResultFile {
	private String indexCode;
	private String tradeDate;
	private int space;
	private int count;
	private int type;
	private Map<String,String[]> datas;
	private String resultName;
	private String resultValue;
	
	
	
	public int getSpace() {
		return space;
	}

	public void setSpace(int space) {
		this.space = space;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getIndexCode() {
		return indexCode;
	}

	public void setIndexCode(String indexCode) {
		this.indexCode = indexCode;
	}

	public String getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}


	public Map<String, String[]> getDatas() {
		return datas;
	}

	public void setDatas(Map<String, String[]> datas) {
		this.datas = datas;
	}

	public String getResultName() {
		return resultName;
	}

	public void setResultName(String resultName) {
		this.resultName = resultName;
	}

	public String getResultValue() {
		return resultValue;
	}

	public void setResultValue(String resultValue) {
		this.resultValue = resultValue;
	}

	public void calResult(){
		this.resultName = "RFSP";
		int size = datas.values().size();
		BigDecimal sum = BigDecimal.ZERO;
		if(size != 0){
			for (String[] value : datas.values()) {
				BigDecimal bd = new BigDecimal(value[1]);
//				sum.setScale(bd.scale(), RoundingMode.HALF_UP);
				sum = sum.add(bd);
			}
			this.resultValue = "  " + sum.divide(new BigDecimal(size), 1, RoundingMode.HALF_UP).toPlainString();
		}else{
			this.resultValue = "  0.0";
		}
	}
	
}
