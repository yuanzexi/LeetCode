package com.domain;

import java.text.ParseException;

public class TimeDuration {
	private String begin;
	private String end;
	private int spaceTime;
	
	public int getSpaceTime() {
		return spaceTime;
	}
	public void setSpaceTime(int spaceTime) {
		this.spaceTime = spaceTime;
	}
	public String getBegin() {
		return begin;
	}
	public void setBegin(String begin) {
		this.begin = begin;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	@Override
	public String toString() {
		return "TimeDuration [begin=" + begin + ", end=" + end + "]";
	}
	public TimeDuration(String begin, String end, int spaceTime) {
		super();
		this.begin = begin;
		this.end = end;
		this.spaceTime = spaceTime;
	}
	
	public int getCount(){
		int count = 0;
		MyCalendar myCalendar = new MyCalendar();
		try {
			myCalendar.setHHmm(begin);
			do {
				count++;
				myCalendar.addMinute(spaceTime);
			} while (end.compareTo(myCalendar.getTimeHHmm()) > 0);
			count++;
			return count;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return -1;
	}
}
