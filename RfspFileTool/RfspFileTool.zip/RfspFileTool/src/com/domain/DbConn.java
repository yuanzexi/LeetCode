package com.domain;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DbConn {
	Logger logger = Logger.getLogger(DbConn.class);
	private String username = null;
	private String password = null;
	private String url = null;
	private String driver = null;
	private Connection conn = null;
	
	
	
	public Connection getConn() {
		return conn;
	}

	public void init() {
		File file = new File("config//DBConfig.properties");
		FileInputStream fis = null;
		Properties p = new Properties();
		try {
			fis = new FileInputStream(file);
			p.load(fis);
			username = p.getProperty("DB_USERNAME");
			password = p.getProperty("DB_PASSWORD");
			url = p.getProperty("DB_URL");
			driver = p.getProperty("DB_DRIVER");
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}finally{
			try {
				if(fis != null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void openConnection() throws Exception{
		Class.forName(driver);
		conn = DriverManager.getConnection(url, username, password);
	}
	
	public void close(){
		if(conn != null){
			try {
				conn.close();
				conn = null;
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
}
