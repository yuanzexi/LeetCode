package com.domain;

import java.util.List;

public class Index {
	private String indexCode;
	private List<TimeDuration> times;
	private String closeTime;
	private int spaceTime;
	private String endTime;
	private String exeTime;
	public boolean isCalDirect(){
		return "0".equals(closeTime);
	}
	
	public int getCount(){
		if(times != null && times.size() > 0){
			int sum = 0;
			for (TimeDuration time: times) {
				if(time.getCount() == -1){
					return -1;
				}else{
					sum += time.getCount();
				}
			}
			return sum;
		}else{
			return 0;//ʱ������ô���
		}
	}
	
	public int calType(){
		if("0".equals(closeTime)){
			return 0;//�����ȡ���̼ۼ�����
		}else{
			if(times != null && times.size() > 0){
				if(endTime.equals(closeTime)){
					return 2;//ֻ���ȡ���̼ۣ�����ȡʱ�����ĩʱ���ʵʱ��
				}else{
					return 1;//��Ҫ��ȡ���̼ۺ�ʱ�����ĩʱ���ʵʱ��
				}
			}else{
				return -1;//ʱ������ô���
			}
		}
		
	}
	
	public String getExeTime() {
		return exeTime;
	}

	public void setExeTime(String exeTime) {
		this.exeTime = exeTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getIndexCode() {
		return indexCode;
	}
	public void setIndexCode(String indexCode) {
		this.indexCode = indexCode;
	}
	public List<TimeDuration> getTimes() {
		return times;
	}
	public void setTimes(List<TimeDuration> times) {
		this.times = times;
	}
	public String getCloseTime() {
		return closeTime;
	}
	public void setCloseTime(String closeTime) {
		this.closeTime = closeTime;
	}
	public int getSpaceTime() {
		return spaceTime;
	}
	public void setSpaceTime(int spaceTime) {
		this.spaceTime = spaceTime;
	}

	@Override
	public String toString() {
		return "Index [indexCode=" + indexCode + ", times=" + times + ", closeTime=" + closeTime + ", spaceTime="
				+ spaceTime + ", endTime=" + endTime + ", exeTime=" + exeTime + "]";
	}
	
	
	
}
