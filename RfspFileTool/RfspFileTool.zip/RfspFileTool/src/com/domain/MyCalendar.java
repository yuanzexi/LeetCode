package com.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MyCalendar {
	private static final long serialVersionUID = 1L;

	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	SimpleDateFormat sdfHms = new SimpleDateFormat("HHmmss");
	SimpleDateFormat sdfHms2 = new SimpleDateFormat("HH:mm");
	
	Calendar calendar;
	/**
	 * 
	 */
	public MyCalendar() {
		calendar = Calendar.getInstance();
	}
	/**
	 * Constructor
	 * @param date
	 */
	public MyCalendar(Date date) {
		calendar = Calendar.getInstance();
		calendar.setTime(date);
	}
	/**
	 * Constructor with string
	 * @param dateStr
	 * @throws Exception
	 */
	public MyCalendar(String dateStr) throws Exception {
		calendar = Calendar.getInstance();
		calendar.setTime(sdf.parse(dateStr));
	}
	
	/**
	 * setTime(HH:mm)
	 * @return
	 * @throws Exception
	 */
	public void setHHmm(String timeStr) throws ParseException{
		String[] split = timeStr.split(":");
		calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(split[0]));
		calendar.set(Calendar.MINUTE, Integer.parseInt(split[1]));
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
	}
	/**
	 * getTimeHH:mm
	 * @return
	 * @throws Exception
	 */
	public String getTimeHHmm() {
		return sdfHms2.format(calendar.getTime());
	}
	/**
	 * addMinute with number
	 * @param number
	 */
	public void addMinute(int number){
		calendar.add(Calendar.MINUTE, number);
	}
	/**
	 * setTime(HHmmss)
	 * @return
	 * @throws Exception
	 */
	public void setTimeHHmmss(String timeStr) throws ParseException {
		
		calendar.setTime(sdfHms.parse(timeStr));
	}
	/**
	 * getTime(HHmmss)
	 * @return
	 * @throws Exception
	 */
	public String getTimeHHmmss() {
		return sdfHms.format(calendar.getTime());
	}
	/**
	 * getDateString(yyyyMMdd)
	 * @return
	 * @throws Exception
	 */
	public String getDateString() throws Exception{
		return sdf.format(getDate());
	}
	/**
	 * getDateString(yyyy.MM.dd)
	 * @return
	 * @throws Exception
	 */
	public String getDateString2() throws Exception{
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy.MM.dd");
		return sdf2.format(getDate());
	}
	/**
	 * getDateString(MM.dd)
	 * @return
	 * @throws Exception
	 */
	public String getDateString3() throws Exception{
		SimpleDateFormat sdf3 = new SimpleDateFormat("MM.dd");
		return sdf3.format(getDate());
	}
	/**
	 * getDate(Date)
	 * @return
	 */
	public Date getDate(){
		return calendar.getTime();
	}
	/**
	 * get first day string of current month(yyyyMMdd)
	 * @return
	 * @throws Exception
	 */
	public String getMonthFirstString() throws Exception{
		return sdf.format(getMonthFirstDay());
	}
	/**
	 * get month string(yyyyMM)
	 * @return
	 * @throws Exception
	 */
	public String getMonthYYYYMM() throws Exception{
		SimpleDateFormat sdf4 = new SimpleDateFormat("yyyyMM");
		return sdf4.format(getMonthFirstDay());
	}
	/**
	 * get first day of current month(yyyyMMdd)
	 * @return
	 */
	public Date getMonthFirstDay(){
		Calendar c = Calendar.getInstance();
		c.setTime(calendar.getTime());
		c.set(Calendar.DAY_OF_MONTH, c.getActualMinimum(Calendar.DAY_OF_MONTH));
		return c.getTime();
	}
	
	/**
	 * get last day string of current month(yyyyMMdd)
	 * @return
	 * @throws Exception
	 */
	public String getMonthLastString() throws Exception{
		return sdf.format(getMonthLastDay());
	}
	/**
	 *  get last day of current month(yyyyMMdd)
	 * @return
	 */
	public Date getMonthLastDay(){
		Calendar c = Calendar.getInstance();
		c.setTime(calendar.getTime());
		c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		return c.getTime();
	}
	
	/**
	 * change the month to the last month
	 */
	public void lastMonth(){
		calendar.add(Calendar.MONTH, -1);
	}
	
	/**
	 * change the day to the next day
	 */
	public void nextDay(){
		calendar.add(Calendar.DAY_OF_MONTH, 1);
	}
	
	/**
	 * change the day with number
	 */
	public void addDay(int number){
		calendar.add(Calendar.DAY_OF_MONTH, number);
	}
	
}
