package com.main;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import org.apache.log4j.PropertyConfigurator;

import com.service.InitService;

public class MainDialog {

	private JFrame frame;
	private JList<String> list;
	private DefaultListModel<String> model;
	private Map<String,String> msgMap = new HashMap<String,String>();
	private static MainDialog instance = new MainDialog();
	private JButton startButton;
	InitService is = new InitService();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		PropertyConfigurator.configure("config/log4j_his.properties");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					MainDialog window = new MainDialog();
					MainDialog window = MainDialog.getInstance();
					window.getFrame().setVisible(true);
					window.startUp();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public JFrame getFrame(){
		return frame;
	}
	
	public JButton getStartButton() {
		return startButton;
	}

	/**
	 * Create the application.
	 */
	private MainDialog() {
		initialize();
	}

	public static MainDialog getInstance(){
		return instance;
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u4E2D\u8BC1\u6307\u6570\u4EA4\u5272\u7ED3\u7B97\u4EF7");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel("\u4E2D\u8BC1\u6307\u6570\u4EA4\u5272\u7ED3\u7B97\u4EF7");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("", Font.PLAIN, 18));
		panel.add(label);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.SOUTH);
		
		JPanel panel_3 = new JPanel();
		panel.add(panel_3, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_4 = new JPanel();
		panel_1.add(panel_4, BorderLayout.CENTER);
		model = new DefaultListModel<String>();
		panel_4.setLayout(new BorderLayout(0, 0));
		list = new JList<String>(model);
		JScrollPane jScrollPane = new JScrollPane(list);
		panel_4.add(jScrollPane);
		
		JPanel panel_5 = new JPanel();
		panel_1.add(panel_5, BorderLayout.SOUTH);
		
		startButton = new JButton("\u8BA1\u7B97");
		panel_5.add(startButton);
		startButton.setFont(new Font("", Font.PLAIN, 15));
		startButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {				
				startButton.setEnabled(false);
				is.loadData();
			    startButton.setEnabled(true);
			}
		});
	}

	/**
	 * ��������
	 */
	public void startUp() {
		String init = is.init();
		if(init != null){
			JOptionPane.showMessageDialog(frame, init);
		}else{
			is.initTimer();
		}
	}
	
	public void showMessage(String indexCode,String msg){
		model.clear();
		msgMap.put(indexCode, msg);
		for (Entry<String, String> entry : msgMap.entrySet()) {
			model.addElement(entry.getKey() + "  :  " + entry.getValue());
		}
		list.setModel(model);
//		JOptionPane.showMessageDialog(frame, msg);
	}
}
